package tabcontainer.mallow.com.tabwithcontainer.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import tabcontainer.mallow.com.tabwithcontainer.R;

/**
 * Company: Mallow Technology
 * Created by bhagya on 18/02/16.
 */
public class TCTab1FirstFragment extends Fragment {

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.tc_tab1_first_fragment, container, false);

        Button btnNext = (Button) rootView.findViewById(R.id.btn_next_first_tab);
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((TCFirstTabFragmentContainer) getParentFragment()).replaceFragment(new TCTab1SecondFragment(), true);
            }
        });

        return rootView;
    }
}
