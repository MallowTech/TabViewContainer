package tabcontainer.mallow.com.tabwithcontainer.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import tabcontainer.mallow.com.tabwithcontainer.R;


/**
 * Company: Mallow Technology
 * Created by bhagya on 11/06/15.
 */
public class TCSecondTabFragmentContainer extends TCBaseContainerFragment {

    private boolean mIsViewInitialized;

    @SuppressLint("InflateParams")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.tc_container_fragment, null);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (!mIsViewInitialized) {
            mIsViewInitialized = true;
            initView();
        }
    }

    /**
     * Method to replace the fragment in the parent container
     */
    private void initView() {
        replaceFragment(new TCTab2FirstFragment(), false);
    }
}
