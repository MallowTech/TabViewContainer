package tabcontainer.mallow.com.tabwithcontainer.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import tabcontainer.mallow.com.tabwithcontainer.R;

/**
 * Company: Mallow Technology
 * Created by bhagya on 18/02/16.
 */
public class TCTab2SecondFragment extends Fragment {

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        View rootView = inflater.inflate(R.layout.tc_tab2_second_fragment, container, false);

        return rootView;
    }
}
