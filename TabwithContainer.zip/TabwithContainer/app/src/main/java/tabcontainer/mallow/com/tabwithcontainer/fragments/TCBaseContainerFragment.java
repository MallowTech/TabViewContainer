package tabcontainer.mallow.com.tabwithcontainer.fragments;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;

import tabcontainer.mallow.com.tabwithcontainer.R;


/**
 * Company: Mallow Technology
 * Created by bhagya on 11/06/15.
 */
@SuppressWarnings("SameParameterValue")
public class TCBaseContainerFragment extends Fragment {

    /**
     * Method to replace the fragment view
     * @param fragment       to be loaded
     * @param addToBackStack boolean to add or not
     */
    public void replaceFragment(Fragment fragment, boolean addToBackStack) {
        FragmentTransaction transaction = getChildFragmentManager().beginTransaction();
        if (addToBackStack) {
            transaction.addToBackStack(null);
        }
        transaction.replace(R.id.container_frameLayout, fragment);
        transaction.commit();
        getChildFragmentManager().executePendingTransactions();
    }

    /**
     * Method to get the pop fragment state
     *
     * @return the status
     */
    public boolean popFragment() {
        boolean isPop = false;
        if (getChildFragmentManager().getBackStackEntryCount() > 0) {
            isPop = true;
            getChildFragmentManager().popBackStack();
        }
        return isPop;
    }
}
