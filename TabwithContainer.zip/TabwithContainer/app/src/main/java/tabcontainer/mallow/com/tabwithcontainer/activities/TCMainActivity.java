package tabcontainer.mallow.com.tabwithcontainer.activities;

import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.os.Bundle;

import tabcontainer.mallow.com.tabwithcontainer.R;
import tabcontainer.mallow.com.tabwithcontainer.fragments.TCFirstTabFragmentContainer;
import tabcontainer.mallow.com.tabwithcontainer.fragments.TCSecondTabFragmentContainer;
import tabcontainer.mallow.com.tabwithcontainer.fragments.TCThirdTabFragmentContainer;

public class TCMainActivity extends FragmentActivity {

    private static final String TAB_1_TAG = "tab_1";
    private static final String TAB_2_TAG = "tab_2";
    private static final String TAB_3_TAG = "tab_3";
    private FragmentTabHost mTabHost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tc_activity_main);

        mTabHost = (FragmentTabHost) findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(), R.id.tabcontent);

        //Adding tab to the tab host.
        mTabHost.addTab(mTabHost.newTabSpec(TAB_1_TAG).setIndicator("Tab 1"), TCFirstTabFragmentContainer.class, null);
        mTabHost.addTab(mTabHost.newTabSpec(TAB_2_TAG).setIndicator("Tab 2"), TCSecondTabFragmentContainer.class, null);
        mTabHost.addTab(mTabHost.newTabSpec(TAB_3_TAG).setIndicator("Tab 3"), TCThirdTabFragmentContainer.class, null);

        mTabHost.setCurrentTab(0);

    }

    @Override
    public void onBackPressed() {
        //Handling the back button press for each tab view and child view in side the fragment
        boolean isPopFragment = false;
        String currentTabTag = mTabHost.getCurrentTabTag();
        switch (currentTabTag) {
            case TAB_1_TAG:
                isPopFragment = ((TCFirstTabFragmentContainer) getSupportFragmentManager().findFragmentByTag(TAB_1_TAG)).popFragment();
                break;
            case TAB_2_TAG:
                isPopFragment = ((TCSecondTabFragmentContainer) getSupportFragmentManager().findFragmentByTag(TAB_2_TAG)).popFragment();
                break;
            case TAB_3_TAG:
                isPopFragment = ((TCThirdTabFragmentContainer) getSupportFragmentManager().findFragmentByTag(TAB_3_TAG)).popFragment();
                break;
        }

        //call the super when there are no Fragment in stack
        if (!isPopFragment) {
                super.onBackPressed();
        }
    }
}
